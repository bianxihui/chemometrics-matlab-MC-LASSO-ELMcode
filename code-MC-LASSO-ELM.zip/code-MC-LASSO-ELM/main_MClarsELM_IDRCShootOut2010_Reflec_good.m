clear;clc;close all;
disp('IDRCShootOut2010_Reflec����,MC-LARS-ELM��LARS_ELM��ELM��Ԥ������')
load IDRCShootOut2010Reflect
names ={'Hemoglobin'};
column = 1;
%-------------------------------����ѡ��------------------------------------
switch column
   case 1
         bestActivationFunctionELM  = 'sig';  bestnodeELM   = 66;%���Ż�����
         bestActivationFunctionlarsELM  = 'sig';  bestnodelarsELM   = 66;%���Ż�����
  
end
names  = labels;
disp(names{column});

X                         = [XcalReflect;XvalReflect];
Y                         = [YcalReflect;YvalReflect];
     %----------------------------���ȷֺ���--------------------------------
     x_train              = XcalReflect;
     y_train              = YcalReflect(:,column);
     x_pred               = XvalReflect;
     y_pred               = YvalReflect(:,column);      
   
[m_train,n_train]        = size(x_train);
%-----------------------LARS����������ѡ�����------------------------------
X = x_train;
X = normalize(X);
y = y_train;
y = center(y);
b1 = lars(X, y, 'lasso', 0, 0, [], 1);
s1 = sum(abs(b1),2)/sum(abs(b1(end,:)));
[s_opt, b_opt, res_mean, res_std] = crossvalidate(@lars, 10, 1000, X, y, 'lasso', 0, 0, [], 0);
cvplot(s_opt, res_mean, res_std);
hold on;
axis tight;
ax = axis;
line([s_opt s_opt], [ax(3) ax(4)], 'Color', 'r', 'LineStyle', '-.');
legend
title('Least Angle Regression (LASSO)');
b_index                  = find(b_opt~=0);
%--------------------------LARS-ELM----------------------------------------
[c_larstrain, c_larsELM, TrainingAccuracy, TestingAccuracy] = elm(x_train(:,b_index),y_train,x_pred(:,b_index),y_pred,0, bestnodelarsELM,bestActivationFunctionlarsELM);
disp('larsELMԤ���RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
rmsecv_larsELM      = rms(c_larstrain'-y_train);
rmsep_larsELM       = rms(c_larsELM'-y_pred);
r_larstrain         = corrcoef(c_larstrain',y_train);
r_larstrain         = r_larstrain(1,2);
r_larsELM           = corrcoef(c_larsELM',y_pred);
r_larsELM           = r_larsELM(1,2);
disp([rmsecv_larsELM,rmsep_larsELM,r_larstrain,r_larsELM]);
P                   = polyfit(c_larsELM',y_pred,1);
yP                  = polyval(P,c_larsELM');
text_size           = 16;
figure;plot(c_larsELM,y_pred,'o'),grid on;
           set(gca,'fontsize',text_size);           
           ylabel('Predicted Value by larsELM','fontsize',text_size)
       hold on;
       plot(c_larsELM,yP,'-r','LineWidth',2);
           cell_string = [' R=' num2str(r_larsELM)];
           text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);
       hold off;
%-----------------------------ELM------------------------------------------
[c_train, c_ELM, TrainingAccuracy, TestingAccuracy] = elm(x_train,y_train,x_pred,y_pred,0, bestnodeELM,bestActivationFunctionELM);
disp('ELMԤ���RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
rmsecv_ELM          = rms(c_train'-y_train);
rmsep_ELM           = rms(c_ELM'-y_pred);
r_train             = corrcoef(c_train',y_train);
r_train             = r_train(1,2);
r_ELM               = corrcoef(c_ELM',y_pred);
r_ELM               = r_ELM(1,2);
disp([rmsecv_ELM,rmsep_ELM,r_train,r_ELM]);
P                   = polyfit(c_ELM',y_pred,1);
yP                  = polyval(P,c_ELM');
text_size           = 16;
figure;plot(c_ELM,y_pred,'o'),grid on;
           set(gca,'fontsize',text_size);           
           %xlabel('True Value','fontsize',text_size);
           ylabel('Predicted Value by ELM','fontsize',text_size)
       hold on;
       plot(c_ELM,yP,'-r','LineWidth',2);
           cell_string = [' R=' num2str(r_ELM)];
           text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);
       hold off;


%--------------------------MC-Lars-ELM-------------------------------------
T                        = 100;
for t = 1:T
    %-----------------------MCѡ�񲿷���Ʒ----------------------------------
    for sub_size = 55;
    rand_index       = randperm(m_train);
    sub_index_rand   = rand_index(1:floor(sub_size*m_train/100));
    sub_index        = sort(sub_index_rand); %LASSO����ѡ��������Ʒ˳���й�ϵ
    end    
    %---------------LARS��ѡ����Ĳ�����Ʒ����ѡ�����-----------------------
    X = x_train(sub_index,:);
    X = normalize(X);
    y = y_train(sub_index);
    y = center(y);
    b1 = lars(X, y, 'lasso', 0, 0, [], 1);
    s1 = sum(abs(b1),2)/sum(abs(b1(end,:)));
    [s_opt, b_opt, res_mean, res_std] = crossvalidate(@lars, 10, 1000, X, y, 'lasso', 0, 0, [], 0);    
    figure;plot(b_opt,'ro-');   
    %------------------------MC-LARS-ELM-----------------------------------
    b_index                  = find(b_opt~=0);    
    [c_larstrain, c_larsELM_each, TrainingAccuracy, TestingAccuracy] = elm(x_train(:,b_index),y_train,x_pred(:,b_index),y_pred,0, bestnodelarsELM,bestActivationFunctionlarsELM);
    C_larsELM(t,:)            = c_larsELM_each;
end    
for t = 1:T
    if t == 1
       c_MCLarsELM           = C_larsELM(1,:);
    else
       c_MCLarsELM           = mean(C_larsELM(1:t,:));
    end
    rmsep_MCLarsELM(t)       = rms(c_MCLarsELM'-y_pred);
    R_MCLarsELM              = corrcoef(c_MCLarsELM',y_pred);
    r_MCLarsELM(t)           = R_MCLarsELM(1,2);
end
close all
disp('MCLarsELMԤ���RMSEP,Ԥ�⼯��R');
disp([rmsep_MCLarsELM(T),r_MCLarsELM(T)]);
figure;plot(rmsep_MCLarsELM);title('rmsep-MCLarsELM');
P                        = polyfit(c_MCLarsELM',y_pred,1);
yP                       = polyval(P,c_MCLarsELM);
text_size                = 16;
figure;plot(c_MCLarsELM,y_pred,'o'),grid on;
           set(gca,'fontsize',text_size);           
           ylabel('Predicted Value by MC-Lars-ELM','fontsize',text_size)
       hold on;
       plot(c_MCLarsELM,yP,'-r','LineWidth',2);
       final_r_MCLarsELM = r_MCLarsELM(T);
       cell_string = [' R=' num2str(final_r_MCLarsELM)];
       text(min(y_pred)+0.03*(max(y_pred)-min(y_pred)),min(y_pred)+0.97*(max(y_pred)-min(y_pred)),cell_string,'fontsize',text_size-1);

       
   %---------------------Ԥ����������ϵ����ʾ--------------------------------
clc
disp('IDRCShootOut2010_Reflec����,MC-LARS-ELM��LARS_ELM��ELM��Ԥ������')
disp(names{column});
disp('MCLarsELMԤ���RMSEP,Ԥ�⼯��R');
disp([rmsep_MCLarsELM(T),r_MCLarsELM(T)]);
disp('larsELMԤ���RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
disp([rmsecv_larsELM,rmsep_larsELM,r_larstrain,r_larsELM]);
disp('ELMԤ���RMSECV,RMSEP,ѵ������Ԥ�⼯��R');
disp([rmsecv_ELM,rmsep_ELM,r_train,r_ELM]);
