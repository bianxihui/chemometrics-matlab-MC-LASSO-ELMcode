clc;clear;close all
disp('IDRCShootOut2010Reflect����,LarsELMԤ��Ĳ����Ż�')
dataname = {'IDRCShootOut2010Reflect'};
eval(['load ', dataname{1}]);
ynames={'Hemoglobin'};
column = 1;
columnname=ynames(column);
disp(columnname);
%----------------------------------����ѡ��--------------------------------
switch column
    case 1 %���Ż� T=500            
         bestActivationFunctionLarsELM  = 'sig';  bestnodeLarsELM   = 66;  
                                                                             
   
end
names  = labels;
disp(names{column});
X                         = [XcalReflect;XvalReflect];
Y                         = [YcalReflect;YvalReflect];
method = 1;
     switch method
     %----------------------------���ȷֺ���--------------------------------
     case 1
     x_train              = XcalReflect;
     y_train              = YcalReflect(:,column);
     x_pred               = XvalReflect;
     y_pred               = YvalReflect(:,column);      
    
     end
[m_train,n_train]        = size(x_train);     
%---------------------------ELM--------------------------------------------
PCA           = 0;
if PCA == 1
    PC        = 10;
    [U,S,V]   = svd(x_train);
    R         = U*S;
    x_trainPCA= R(:,1:PC);
    [U,S,V]   = svd(x_pred);
    R         = U*S;    
    x_predPCA = R(:,1:PC);
end
ActivationFunction  = {'sig','sin','hardlim','tribas','radbas'};
T_stalitity   = 500;
for i = 1:5  
for j =1:100 
for tt = 1:T_stalitity
    [c_train(tt,:), c_ELM(tt,:), TrainingAccuracy, TestingAccuracy] = elm(x_train,y_train,x_pred,y_pred,0, j, ActivationFunction{i});
    rmsecv_ELM(tt)     = rms(c_train(tt,:)'-y_train);
    rmsep_ELM(tt)      = rms(c_ELM(tt,:)'-y_pred);
    R_train            = corrcoef(c_train(tt,:)',y_train);
    r_train(tt)        = R_train(1,2);
    R_ELM              = corrcoef(c_ELM(tt,:)',y_pred);
    r_ELM(tt)          = R_ELM(1,2);
end    
    mean_rmsepELM(i,j) = mean(rmsep_ELM);   SD_remspELM(i,j)     = std(rmsep_ELM); 
    mean_rmsecvELM(i,j) = mean(rmsecv_ELM); SD_rmsecvELM(i,j)    = std(rmsecv_ELM); 
    mean_rtrain(i,j)   = mean(r_train);     SD_rtrain(i,j)       = std(r_train);  
    mean_rELM(i,j)     = mean(r_ELM);       SD_rELM(i,j)         = std(r_ELM);  stability_rELM = mean_rELM./SD_rELM;
    
end
end
%-----------------------����meanRMSEPѰ����Сֵ-----------------------------
disp('����meanRMSEPѰ����СֵΪ��Ѳ���');
[min_m_index min_n_index] = find(mean_rmsepELM ==min(min(mean_rmsepELM)));
min_mean_rmsepELM = min(mean_rmsepELM);
disp('��Ѽ���� �����������Ŀ')
disp (ActivationFunction{min_m_index}), disp(min_n_index)
%-----------------------����stability_rELMѰ�����ֵ-----------------------------
disp('����stability_rELMѰ�����ֵΪ��Ѳ���');
[max_m_index max_n_index] = find(stability_rELM == max(max(stability_rELM)));
max_r_ELM = max(stability_rELM);
disp('��Ѽ���� �����������Ŀ');
disp (ActivationFunction{max_m_index}), disp(max_n_index);
figure; surf(mean_rmsepELM);title('mean-rmsepELM');
figure; surf(stability_rELM);title('stability-rELM');