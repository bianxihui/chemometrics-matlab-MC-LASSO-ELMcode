clear;clc;close all;
disp('IDRCShootOut2010_Reflec����,MC-LARS-ELM��LARS_ELM��ELM��Ԥ������')
load IDRCShootOut2010Reflect
names ={'Hemoglobin'};
column = 1;
%-------------------------------����ѡ��------------------------------------
switch column
   case 1
         bestActivationFunctionELM  = 'sig';  bestnodeELM   = 66;%���Ż�����
         bestActivationFunctionlarsELM  = 'sig';  bestnodelarsELM   = 66;%���Ż�����
    
end
names  = labels;
disp(names{column});

X                         = [XcalReflect;XvalReflect];
Y                         = [YcalReflect;YvalReflect];
method = 1;
     switch method
     %----------------------------���ȷֺ���--------------------------------
     case 1
     x_train              = XcalReflect;
     y_train              = YcalReflect(:,column);
     x_pred               = XvalReflect;
     y_pred               = YvalReflect(:,column);      
   
     end
[m_train,n_train]        = size(x_train);     
T                        = 100;
T_stalitity              = 20;
for tt = 1:T_stalitity 
disp(tt);
%---------------------------MC-ELM-------------------------------------
for t = 1:T
    sub_size = 50;
    rand_index        = randperm(m_train);
    sub_index         = rand_index(1:floor(sub_size*m_train/100));
    [C_train(t,:), C_ELM(t,:), TrainingAccuracy, TestingAccuracy] = elm(x_train(sub_index,:),y_train(sub_index),x_pred,y_pred,0, bestnodeELM,bestActivationFunctionELM);

end
c_MCELM(tt,:)    = mean(C_ELM);
rmsep_MCELM(tt)  = rms(c_MCELM(tt,:)'-y_pred);
RPD_MCELM(tt)    = std(y_pred)/std(c_MCELM(tt,:)'-y_pred);
R_MCELM          = corrcoef(c_MCELM(tt,:)',y_pred);
r_MCELM(tt)      = R_MCELM(1,2);
end
mean_rmsep_MCELM      = mean(rmsep_MCELM);    std_rmsep_MCELM     = std(rmsep_MCELM);
mean_r_MCELM          = mean(r_MCELM);        std_r_MCELM         = std(r_MCELM);

disp('the mean and std of RMSEP for MCELM');
disp([mean_rmsep_MCELM std_rmsep_MCELM]);
disp('the mean and std of R for MCELM');
disp([mean_r_MCELM std_r_MCELM]);
