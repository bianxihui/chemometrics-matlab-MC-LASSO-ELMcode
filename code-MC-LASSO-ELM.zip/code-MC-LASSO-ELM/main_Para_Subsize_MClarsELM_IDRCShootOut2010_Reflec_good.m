clear;clc;close all;
disp('IDRCShootOut2010Reflect����,MC-LARS-ELM��ģ��ѵ����Ʒ�Ӽ�����Ʒ�ٷ����Ż�');
load IDRCShootOut2010Reflect
names ={'Hemoglobin'};
column = 1;
%-------------------------------����ѡ��------------------------------------
switch column
   case 1
         bestActivationFunctionELM  = 'sig';  bestnodeELM   = 66;%���Ż�����
         bestActivationFunctionlarsELM  = 'sig';  bestnodelarsELM   = 66;%���Ż�����
   
end
names  = labels;
disp(names{column});

X                         = [XcalReflect;XvalReflect];
Y                         = [YcalReflect;YvalReflect];
method = 1;
     switch method
     %----------------------------���ȷֺ���--------------------------------
     case 1
     x_train              = XcalReflect;
     y_train              = YcalReflect(:,column);
     x_pred               = XvalReflect;
     y_pred               = YvalReflect(:,column);      
    
     end
[m_train,n_train]        = size(x_train);

%--------------------------MC-Lars-ELM-------------------------------------
sub_size = 5:5:100;
for k = 1:length(sub_size)
T                 = 100; 
for t = 1:T

    %-----------------------MCѡ�񲿷���Ʒ----------------------------------
    rand_index       = randperm(m_train);
    sub_index_rand   = rand_index(1:round(sub_size(k)*m_train/100));
    sub_index        = sort(sub_index_rand); 
    %---------------LARS��ѡ����Ĳ�����Ʒ����ѡ�����-----------------------
    X = x_train(sub_index,:);
    X = normalize(X);
    y = y_train(sub_index);
    y = center(y);
    b1 = lars(X, y, 'lasso', 0, 0, [], 1);
    s1 = sum(abs(b1),2)/sum(abs(b1(end,:)));
    [s_opt, b_opt, res_mean, res_std] = crossvalidate(@lars, 5, 1000, X, y, 'lasso', 0, 0, [], 0);    
    figure;plot(b_opt,'ro-');   
    %------------------------MC-LARS-ELM-----------------------------------
    b_index                  = find(b_opt~=0);    
    [c_larstrain, c_larsELM_each, TrainingAccuracy, TestingAccuracy] = elm(x_train(sub_index,b_index),y_train(sub_index),x_pred(:,b_index),y_pred,0, bestnodelarsELM,bestActivationFunctionlarsELM);
    C_larsELM(t,:)            = c_larsELM_each;
end    
   c_MCLarsELM           = mean(C_larsELM);
   rmsep_MCLarsELM       = rms(c_MCLarsELM'-y_pred);
   Rmsep_sub_size(k)     = rmsep_MCLarsELM;   
end
%-------------------��Ҫ����ͼ������ı�������------------------------------
clc,close all
disp('NIRData����,MC-LARS-ELM��ģ��ѵ����Ʒ�Ӽ�����Ʒ�ٷ����Ż�');
figure;plot(sub_size,Rmsep_sub_size,'*b-');
       text_size = 16; 
       set(gca,'fontsize',text_size);
       title('rmsep-MCLarsELM','fontsize',text_size);
       xlabel('Number of iterations','fontsize',text_size);
       ylabel('RMSEP','fontsize',text_size);
