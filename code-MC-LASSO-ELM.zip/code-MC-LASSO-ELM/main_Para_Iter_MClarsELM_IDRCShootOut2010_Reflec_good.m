clear;clc;close all;
disp('IDRCShootOut2010Reflect����,MC-LARS-ELM��ģ�����������Ż�')
load IDRCShootOut2010Reflect
names ={'Hemoglobin','Glucose','Cholesterol'};
column = 1;
%-------------------------------����ѡ��------------------------------------
switch column
   case 1
         bestActivationFunctionELM  = 'sig';  bestnodeELM   = 66;%  ���Ż�����
         bestActivationFunctionlarsELM  = 'sig';  bestnodelarsELM   = 66;%  ���Ż�����
   
end
names  = labels;
disp(names{column});

X                         = [XcalReflect;XvalReflect];
Y                         = [YcalReflect;YvalReflect];
method = 1;
     switch method
     %----------------------------���ȷֺ���--------------------------------
     case 1
     x_train              = XcalReflect;
     y_train              = YcalReflect(:,column);
     x_pred               = XvalReflect;
     y_pred               = YvalReflect(:,column);      
     
     end
[m_train,n_train]        = size(x_train);
%--------------------------MC-Lars-ELM-------------------------------------
T                 = 100;
for t = 1:T
    %-----------------------MCѡ�񲿷���Ʒ----------------------------------
    for sub_size = 55;
    rand_index       = randperm(m_train);
    sub_index_rand   = rand_index(1:floor(sub_size*m_train/100));
    sub_index        = sort(sub_index_rand); 
    end    
    %---------------LARS��ѡ����Ĳ�����Ʒ����ѡ�����-----------------------
    X = x_train(sub_index,:);
    X = normalize(X);
    y = y_train(sub_index);
    y = center(y);
    b1 = lars(X, y, 'lasso', 0, 0, [], 1);
    s1 = sum(abs(b1),2)/sum(abs(b1(end,:)));
    [s_opt, b_opt, res_mean, res_std] = crossvalidate(@lars, 10, 1000, X, y, 'lasso', 0, 0, [], 0);    
    figure;plot(b_opt,'ro-');   
    %------------------------MC-LARS-ELM-----------------------------------
    b_index                  = find(b_opt~=0);
    [c_larstrain, c_larsELM_each, TrainingAccuracy, TestingAccuracy] = elm(x_train(sub_index,b_index),y_train(sub_index),x_pred(:,b_index),y_pred,0, bestnodelarsELM,bestActivationFunctionlarsELM);
    C_larsELM(t,:)            = c_larsELM_each;
end    
for t = 1:T
    if t == 1
       c_MCLarsELM           = C_larsELM(1,:);
    else
       c_MCLarsELM           = mean(C_larsELM(1:t,:));
    end
    rmsep_MCLarsELM(t)       = rms(c_MCLarsELM'-y_pred);
    R_MCLarsELM              = corrcoef(c_MCLarsELM',y_pred);
    r_MCLarsELM(t)           = R_MCLarsELM(1,2);
end
%-------------------��Ҫ����ͼ������ı�������-------------------------------
clc, close all
disp('IDRCShootOut2010Reflect����,MC-LARS-ELM��ģ�����������Ż�')
figure;plot(rmsep_MCLarsELM,'r-');
       text_size = 16; 
       set(gca,'fontsize',text_size);
       title('rmsep-MCLarsELM','fontsize',text_size);
       xlabel('Number of iterations','fontsize',text_size);
       ylabel('RMSEP','fontsize',text_size); 
       